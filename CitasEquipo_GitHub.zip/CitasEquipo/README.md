# Citas Equipo — Android v1.0

App para el equipo de ventas (es distinta de «Citas Amigo Renta», que sigue siendo la app completa de la encargada).
Cada vendedor entra con su nombre y PIN (permiso «Solo app de Citas» en la App Operativa) y ve solo: agendar y ver
citas, las habitaciones disponibles con fotos (para compartir con el cliente) y subir los enlaces de sus anuncios del
día. Abre la página /ci del servidor amigorentacliente; todo llega a la app de Marketing y Ventas y a Citas Amigo Renta.
Se compila con GitHub Actions (.github/workflows/compilar-apk.yml).
